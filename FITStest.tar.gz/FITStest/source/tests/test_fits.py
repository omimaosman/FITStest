from fits import fits


def test1():
	''' Test that the file exists'''
	try:
		fit_data = '../../spectra-data/spec-4055-55359-0010.fits'
		data = open('fit_data', mode="r")
	except IOError:
		print("Error: file '{0}' could not be opened.".format(filename))
		sys.exit(1)



