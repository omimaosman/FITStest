#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 30 10:08:05 2018

@author: Omima
"""

from astropy.io import fits
import argparse
import os

class spectrum(object):
	def __init__(self, filename=None):     
		self.filename = filename
	@property
	def hdu_num(self):     
		hdu_list = fits.open(self.filename)
		num_hdus = len(hdu_list)
		#mytype = hdu_list.info()
		return num_hdus

    

s = spectrum('/home/omima/Documents/rep/FITStest/spectra-data/spec-4055-55359-0001.fits')
print(s.hdu_num())
