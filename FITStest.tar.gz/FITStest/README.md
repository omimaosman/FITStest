# FITStest
SciCoder exercise to play with FITS files
