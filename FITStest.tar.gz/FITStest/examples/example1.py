from FITS_test import spectrum

''' Example of the use of FITS_test module 
	FITS_test module reads in a fits file and returns the number of HDUs'''



filename = '../../spectra-data/spec-4055-55359-0010.fits'


s = spectrum(filename)

print(s.hdu_num)
